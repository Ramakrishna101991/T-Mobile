1. In Component we should have Return Types for all the function
2. We should define types for readingList$ and totalUnread$ in reading-list.component.ts and total-count.component.ts
3. Can we Wrap our CSS with :host {} so it will not efect other pages
4. Instead of using this two times in html we can directly write this one time and use it with as for next places
5. Null Checks are missing at some places
6. We can change this matBadge="{{ count }}" to [matBadge]="count" as this is good Practice in angular and same for Image Src as well
7. 
