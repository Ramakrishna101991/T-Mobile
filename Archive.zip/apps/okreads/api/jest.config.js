module.exports = {
  name: 'okreads-api',
  preset: '../../../jest.config.js',
  coverageDirectory: '../../../coverage/apps/okreads/api',
  globals: { 'ts-jest': { tsConfig: '<rootDir>/tsconfig.spec.json' } },
};
